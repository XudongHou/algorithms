package com.hxd.graphs.undirectedGraphs;

/**
 * 通过重命名一幅图中的顶点就能够使之变得和另一幅图完全相同,这两幅图就是同构的
 * @author 候旭东 20170219
 * */

public class MemoryOfGraph {
}
